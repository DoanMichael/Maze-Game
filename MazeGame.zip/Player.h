#ifndef _PLAYER_H_
#define _PLAYER_H_
#include <iostream>
//sets position of each square in maze
struct Position 
{
	int row;
	int col;
	bool operator==(const Position &other) 
	{
		return row == other.row && col == other.col;
	}
};
//creates player and all of the recorded data inside
class Player 
{
public:
	//constructor
	Player(const std::string name, const bool is_human);
	//inline member function
	std::string get_name() const 
	{
		return name_; 
	} 
	// inline member function
	int get_points() const 
	{
		return points_; 
	}
	//inline member function
	Position get_position() const 
	{
		return pos_; 
	}  
	//inline member function
	bool is_human() const 
	{
		return is_human_; 
	} 
	//changes points when treasure is picked up
	void ChangePoints(const int x);  
	//sets position
	void SetPosition(Position pos);

	std::string ToRelativePosition(Position other);
	friend std::ostream& operator<<(std::ostream &out, Player p);
//player data
private:
	std::string name_;
	int points_;
	Position pos_;
	bool is_human_;
};

#endif