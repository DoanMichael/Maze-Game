#include "Player.h"
//constructor 
Player::Player(const std::string name, const bool is_human)
{
    name_ = name;
    points_ = 0;
    is_human_ = is_human;

    if(is_human)
    {
        pos_.col = 0;
        pos_.row = 0;
    }
}
// Overload the output stream operator << to out object that are part of the player class
std::ostream& operator<<(std::ostream &out, Player p)
{
    out << "Player name: " << p.get_name() << " score: " << p.get_points() << ". ";
    return out;
}

void Player::ChangePoints(const int x)
{ 
    points_ += x; 
}

void Player::SetPosition(Position pos)
{ 
    pos_ = pos;
}

std::string Player::ToRelativePosition(Position other)
{
    if((pos_.row + 1 == other.row) && (pos_.col == other.col))
    {
        return "DOWN";
    } 

    else if((pos_.row - 1 == other.row) && (pos_.col == other.col))
    {
        return "UP";
    } 

    else if((pos_.row == other.row) && (pos_.col + 1 == other.col))
    {
        return "RIGHT";
    } 

    else if((pos_.row == other.row) && (pos_.col - 1 == other.col))
    {
        return "LEFT";
    }

    return "NONE"; 
}