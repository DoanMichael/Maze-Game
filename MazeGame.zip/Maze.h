#ifndef _MAZE_H_
#define _MAZE_H_
#include <vector>
#include <string> 
#include <stdlib.h> 
#include <time.h>       
#include "Player.h"
//creates different types of squares (treasure1 and treasure2 are added to boost the "fun aspect" of the base game)
enum class SquareType 
{ 
	Wall, Exit, Empty, Human, Enemy, Treasure, Treasure1, Treasure2 
};

std::string SquareTypeStringify(SquareType sq);

// gets a random number between a min and a max
int random_number(int min, int max);
//creates each square on the board
class Board 
{
	//sets board values and allows users to move around the maze
	public:
		Board();
		// you should be able to change the size of your board by changing these numbers and the numbers in the arr_ field
		int get_rows() const 
		{
			return 4; 
		}   
		int get_cols() const 
		{
			return 4; 
		}  
		//gets the value of the square
		SquareType get_square_value(Position pos) const; 
		//sets the value of the square
		void SetSquareValue(Position pos, SquareType value);
		//get the possible Positions that a Player could move to (not off the board or into a wall)
		std::vector<Position> GetMoves(Player *p);
		// Move a player to a new position on the board. Return true if they moved successfully, false otherwise.
		bool MovePlayer(Player *p, Position pos);
		// Get the square type of the exit square
		SquareType GetExitOccupant();
		// You probably want to implement this
		friend std::ostream& operator<<(std::ostream& os, const Board &b);
	//sets the size of the maze
	private:
		SquareType arr_[4][4];
		int rows_; 
		int cols_;
};  

class Maze 
{
	//Sets game turns
	public:
		//constructor
		Maze(); 
		//destructor
		~Maze(); 
		// initialize a new game, given one human player and a number of enemies to generate
		void NewGame(Player *human, const int enemies);
		// have the given Player take their turn
		bool TakeTurn(Player *p);
		// Get the next player in turn order
		Player* GetNextPlayer();
		// return true iff the human made it to the exit or the enemies ate all the humans
		bool IsGameOver();
		//string info about the game's conditions after it is over
		std::string GenerateReport();
		friend std::ostream& operator<<(std::ostream& os, Maze &m);
		Board* get_board();
	//Sets turn count
	private:
		Board *board_; 
		std::vector<Player *> players_;
		int turn_count_;
};

#endif