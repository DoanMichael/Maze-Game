#include "Maze.h"
#include <cstdlib>
#include<ctime>
#include <algorithm>
//generates random number
int random_number(int min, int max)
{
  return (rand() % (max - min + 1) + min);
}
//creates board and sets probabilities of each type of tile
Board::Board()
{
    rows_ = 4;
    cols_ = 4;
    //treasure1 and treasure2 are added in for the "fun aspect" of the game
    std::vector<SquareType> tiles = 
    { 
        SquareType::Empty, SquareType::Wall, SquareType::Treasure, SquareType::Treasure1, SquareType::Treasure2
    };
    
    int probability = 0; 
    srand(time(0));
    //probability for each tile
    for(int i = 0; i < 4; i++) 
    {
        for(int j = 0; j < 4; j++)
        {
            if(!(i == 0 && j == 0) && !(i == 3 && j == 3))
            {
                probability = random_number(1, 100);
                //sets walls
                if(probability <= 20)
                {
                    SetSquareValue(Position{i,j}, tiles[1]);
                } 
                //sets treasures
                else if(probability > 20 && probability <= 30)
                {
                    SetSquareValue(Position{i,j}, tiles[2]);
                } 
                //sets rare treasures (added in to make "more fun")
                else if(probability > 30 && probability <= 40)
                {
                    SetSquareValue(Position{i,j}, tiles[3]); 
                }
                //sets super rare treasure (added in to make "more fun")
                else if(probability >= 90 && probability < 95)
                {
                    SetSquareValue(Position{i,j}, tiles[4]); 
                }
                //sets empty tiles
                else
                {
                    SetSquareValue(Position{i,j}, tiles[0]);
                }
            }
        }
    }

    arr_[0][0] = SquareType::Human;
    arr_[3][3] = SquareType::Exit;
}
//gets value of square
SquareType Board::get_square_value(Position pos) const
{
    return arr_[pos.row][pos.col];
}
//sets value of square
void Board::SetSquareValue(Position pos, SquareType value)
{
    arr_[pos.row][pos.col] = value;
}
//gets moves of player
std::vector<Position> Board::GetMoves(Player *p)
{
    std::vector<Position> moves;
    Position player_pos = p->get_position();
    
    if((player_pos.row + 1 < rows_) && (arr_[player_pos.row + 1][player_pos.col] != SquareType::Wall))
    {
        moves.push_back(Position{player_pos.row + 1, player_pos.col});
    } 

    if((player_pos.row - 1 >= 0) && (arr_[player_pos.row - 1][player_pos.col] != SquareType::Wall))
    {
        moves.push_back(Position{player_pos.row - 1, player_pos.col});
    }

    if(player_pos.col + 1 < cols_ && (arr_[player_pos.row][player_pos.col + 1] != SquareType::Wall))
    {
        moves.push_back(Position{player_pos.row, player_pos.col + 1});
    } 

    if(player_pos.col - 1 >= 0 && (arr_[player_pos.row][player_pos.col - 1] != SquareType::Wall))
    {
        moves.push_back(Position{player_pos.row, player_pos.col - 1});
    }

    return moves;
}

//gets available moves and moves the user based on option
bool Board::MovePlayer(Player *p, Position pos)
{
    std::vector<Position> moves = GetMoves(p);
    SquareType pos_tile = get_square_value(pos);
    SquareType player_tile = get_square_value(p->get_position());
    Position old_pos = p->get_position();
    
    //goes through each move the player could make 
    for(int i = 0; i < int (moves.size()); ++i)
    {
        //makes sure that the inputed movement is valid
        if(pos == moves[i])
        {
            //condition if the enemy moves onto an enemy
            if(player_tile == pos_tile)
            {
                    return true;
            }
            //enemy is not able to go on the exit title
            if(player_tile == SquareType::Enemy)
            {
                if(pos_tile == SquareType::Exit)
                {
                    return true;
                }
            }

            if(player_tile == SquareType::Human)
            {
                if(pos_tile == SquareType::Enemy)
                {
                    p->SetPosition(pos);
                    return true;
                }
            }
            //adds points based on treasure picked up (treasure1 and treasure2 points are the "more fun" aspect added to the assignment)
            if(pos_tile == SquareType::Treasure)
            {
                    p->ChangePoints(100);
            }

            if(pos_tile == SquareType::Treasure1)
            {
                    p->ChangePoints(500);
            }

            if(pos_tile == SquareType::Treasure2)
            {
                    p->ChangePoints(690);
            }

            arr_[pos.row][pos.col] = player_tile;
            arr_[old_pos.row][old_pos.col] = SquareType::Empty;
            p->SetPosition(pos);
            return true;
        }
    }

    return false;
}
//sets exit
SquareType Board::GetExitOccupant()
{
    return arr_[3][3];
}
//sets each emoji to each value (treasure1 and treasure2 are the "more fun" aspect added to the assignment)
std::ostream& operator<<(std::ostream& os, const Board &b)
{
    SquareType title;
    for(int i = 0; i < 4; ++i)
    {
        for(int j = 0; j < 4; ++j)
        {
            title = b.get_square_value(Position{i,j});

            if(title == SquareType::Wall)
            {
                os << "🌵";
            } 

            else if(title == SquareType::Exit)
            {
                os << "🐴";
            } 

            else if(title == SquareType::Empty)
            {
                os << "⬜️";
            } 

            else if(title == SquareType::Human)
            {
                os << "🤠";
            } 

            else if(title == SquareType::Enemy)
            {
                os << "👽";
            } 

            else if(title == SquareType::Treasure)
            {
                os << "🥩";
            }

            else if(title == SquareType::Treasure1)
            {
                os << "🔫";
            }

            else
            {
                os << "🍑";
            }
        }

        os << "\n";
    }

    return os;
}
//board
Maze::Maze()
{
    Board* b = new Board{};
    board_ = b;
    turn_count_ = -1;
}
//Clears board
Maze::~Maze()
{
    std::cout << "Continue?" << std::endl;

    for(int i = 0; i < int (players_.size()); ++i)
    {
        free (players_[i]);
    }

    free (board_);
}
//New game
void Maze::NewGame(Player *human, const int enemies) 
{
    players_.push_back(human);
    for(int i = 0; i < enemies; ++i) 
    {
        players_.push_back(new Player{"Alien " + std::to_string(i), false});
    }

    if(enemies != 0)
    {
        int enemies_i = 1;
        for(int i = 1; i < 4; ++i) 
        {
            for(int j = 1; j < 4; ++j) 
            {
                if(board_->get_square_value(Position{i,j}) == SquareType::Empty) 
                {
                    players_[enemies_i]->SetPosition(Position{i,j});
                    board_->SetSquareValue(Position{i,j}, SquareType::Enemy);
                    enemies_i++;
                }

                if(enemies_i > enemies)
                {
                    return;
                }
            }
        }
    }
}
//Sets turns
bool Maze::TakeTurn(Player *p)
{
    // get the list of moves the player can make
    std::vector<Position> moves = board_->GetMoves(p);
    std::string choice;
    bool move = true;
    bool endGame = IsGameOver();
    
    if(endGame)
    {
        turn_count_ = 0;
        return false;
    }

    while(move)
    {
        std::cout << p->get_name() << " can move: ";
        
        for(int i = 0; i < int (moves.size()); ++i)
        {
            std::cout << p->ToRelativePosition(moves[i]) << " ";
            p->ToRelativePosition(moves[i]);
        } 

        std::cout << "\n";
        std::cout << "Make your move: ";
        getline(std::cin, choice);
        // transform -> makes user input lower case
        std::transform(choice.begin(), choice.end(), choice.begin(), [](unsigned char c){ return std::tolower(c); }); 
        Position player_move;
        std::cout << "Move: " << choice << std::endl;
        player_move = p->get_position();
        
        if(choice == "left") 
        {
            player_move.col--;  
        } 

        else if(choice == "right") 
        {
            player_move.col++;
        } 

        else if (choice == "down") 
        {
            player_move.row++;
        } 

        else if (choice == "up") 
        {
            player_move.row--;
        } 

        else
        {
            std::cout << "Select a valid move\n"; 
            player_move.row = player_move.col = -1;
        }

        move = !(board_->MovePlayer(p, player_move));
    }
    
    std::cout << "Failed" << std::endl;
    return true;
}
//sets player turns
Player* Maze::GetNextPlayer()
{
    //get to the next player
    turn_count_++; 
    //check if we are at the last player so it'll loop back to player 1
    if(turn_count_ >= int (players_.size()))
    { 
        turn_count_ = 0;
    }

    return players_[turn_count_];
}
//checks if player is at the exit to set the game as over
bool Maze::IsGameOver() 
{
    //checks to see if user is at the same space as enemy (if so, game is over)
    for(int i = 1; i < int (players_.size()); ++i) 
    {
        if(players_[0]->get_position() == players_[i]->get_position()) 
        {
            players_[i]->ChangePoints(1);
            std::cout << "GAME OVER!" << std::endl; 
            return true;
        }
    }
    //checks to see if user is at the end (if so, game is over and user wins)
    if(players_[0]->get_position() == Position{3,3}) 
    {
        players_[0]->ChangePoints(1);
        std::cout << "YOU WIN!" << std::endl;
        return true;
    }

    return false; 
}
//returns results of game
std::string Maze::GenerateReport() 
{
    std::string result = players_[turn_count_]->get_name() + " has " + std::to_string(players_[turn_count_]->get_points()) + " points. ";
    turn_count_++;
    return result;
}

std::ostream& operator<<(std::ostream& os, Maze &m) 
{
    for(int i = 0; i < int (m.players_.size()); ++i)
    {
        os << m.GenerateReport() << "\n"[i <= int (m.players_.size()) - 1];
    }

    return os;
}

Board* Maze::get_board() 
{
    return board_;
}