#include "Maze.h"
#include <stdlib.h>
#include <time.h>       
//starts game with new maze
Maze start_game();
//clears screen once game is over
void clear_screen();

int main()
{
    Maze end_game = start_game();
    std::cout << end_game << std::endl;   
}
//takes in user input for name, and then starts game
Maze start_game()
{
    std::string name;
    Maze maze{};
    std::cout << "Enter your name: ";
    getline(std::cin, name);
    Player* human = new Player{name, true};
    maze.NewGame(human, 2);
    bool conti = true;
    std::string c;
    while(conti)
    {
        clear_screen();
        std::cout << *maze.get_board() << std::endl;
        conti = maze.TakeTurn(maze.GetNextPlayer());
    }

    return maze;
}
//clears screen
void clear_screen()
{
  std::cout << "\033[2J\033[1;1H";
}
